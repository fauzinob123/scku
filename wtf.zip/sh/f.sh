#!/system/xbin/bash
clear
toilet -f slant --gay "TOOLS" 
toilet -f slant --gay "M.F2ZY"
echo "\033[32;1m TOOLS Yang Tersedia :"
echo "\033[35;1m1.""\033[36;1mFacebook"
echo "\033[35;1m2.""\033[36;1mKamera"
echo "\033[35;1m3.""\033[36;1mSpam"
echo "\033[35;1m4.""\033[36;1mIp Website"
echo "\033[35;1m5.""\033[36;1mTerkey"
echo "\033[35;1m6.""\033[36;1mMalicious"
echo "\033[35;1m7.""\033[36;1mNIK dan KK GRATIS"
echo "\033[35;1m8.""\033[36;1mTembak kuota XL"
echo "\033[35;1m9.""\033[36;1mTools Bajinganv6"
echo "\033[35;1m0.""\033[36;1mKeluar"
echo "\033[33;1m Pilih Angka:"
read mrrm

if [ $mrrm = 1 ] || [ $mrrm = 1 ]
then
clear
cd sc/fb/
python2 run.py
fi

if [ $mrrm = 2 ] || [ $mrrm = 2 ]
then
clear
cd sc/Saycheese/
bash saycheese.sh
fi

if [ $mrrm = 3 ] || [ $mrrm = 3 ]
then
clear
cd sc/spam/
sh spam.sh
fi

if [ $mrrm = 4 ] || [ $mrrm = 4 ]
then
clear
cd sc/rhawk/
php rhawk.php
fi

if [ $mrrm = 5 ] || [ $mrrm = 5 ]
then
clear
cd sc/terkey
python2 terkey.py
fi

if [ $mrrm = 6 ] || [ $mrrm = 6 ]
then
clear
cd sc/Malicious/
pip2 install -r requirements.txt
python2 malicious.py
fi

if [ $mrrm = 7 ] || [ $mrrm = 7 ]
then
clear
cd sc/kkktp/
php kkktp.php
fi

if [ $mrrm = 8 ] || [ $mrrm = 8 ]
then
clear
cd sc/semut/
python dor.py
fi

if [ $mrrm = 9 ] || [ $mrrm = 9 ]
then
clear
cd sc/BAJINGANv6
sh BAJINGAN.sh 
fi

if [ $mrrm = 0 ] || [ $mrrm = 0 ]
then
exit
fi

