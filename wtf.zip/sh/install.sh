#!/system/xbin/bash
clear
pkg update -y
pkg upgrade -y
pkg install openssh -y 
pkg install python -y
pkg install python2 -y
pkg install toilet -y
pkg install figlet -y
pkg install bash -y
pkg install php -y
pkg install nano -y
pkg install git -y
pkg install curl -y
pkg install mc -y
pip2 install requests mechanize
pkg install termcolor -y
pkg install lolcat
pkg install ruby -y