spammBlackHeat78

$ pkg update && pkg upgrade

$ pkg install python2

$ pkg install php

$ pkg install toilet

$ pkg install nano ruby figlet

$ gem install lolcat

$ pkg install git

$ git clone https://github.com/BLACheat78/spammblackheat78.git

$ cd spammblackheat78

$ sh Blackspamm.sh


pilih no spamm yang kamu ingin kan contoh no : 1  (enter)

spamm sms berulang kali ke nomor yang anda tuju

tools spammblackheat78 ini akan di perbaharui tiap bulanya

( saya tidak bertanggung jawab atas yang anda lakukan.! )
