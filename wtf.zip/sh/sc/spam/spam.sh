#!/system/xbin/bash
clear
git clone https://github.com/amsitlab/smsid-java.git
cd ./sdcard/sc/Tull
chmod +x ./install
apt install ./smsid_1.1_all.deb
clear

toilet -f slant --gay "SPAM"
echo "\033[33;1m Macam-macam tool untuk spam"
echo "\033[36;1m★""\033[34;1mIndonesia Security Lite""\033[36;1m★"
echo "\033[32;1m Spam Yang Tersedia :"
echo "\033[35;1m1.""\033[36;1mBukalapak BELUM WORK"
echo "\033[35;1m2.""\033[36;1mTelkomsel"
echo "\033[35;1m3.""\033[36;1mGrab"
echo "\033[35;1m4.""\033[36;1mTokopedia"
echo "\033[35;1m5.""\033[36;1mCodaShop"
echo "\033[35;1m6.""\033[36;1mSurveyon"
echo "\033[35;1m7.""\033[36;1mCustom"
echo "\033[35;1m8.""\033[36;1mJdid"
echo "\033[35;1m9.""\033[36;1mHOOQ"
echo "\033[35;1m10.""\033[36;1mMatahari"
echo "\033[35;1m11.""\033[36;1mKFC"
echo "\033[35;1m12.""\033[36;1mPHD"
echo "\033[35;1m13.""\033[36;1mWhiskas" 
echo "\033[35;1m14.""\033[36;1mZIPAY"
echo "\033[31;1m0. Keluar"
echo "\033[33;1m Pilih Angka:"
read mrrm

if [ $mrrm = 1 ] || [ $mrrm = 1 ]
then
clear
toilet -f slant "Bukalapak"
echo "\033[31;1mJenis Spam:""\033[37;1mChat WhatsApp"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mSGB-Team"
clear
cd Tul/
php 1.php
fi

if
[ $mrrm = 2 ] || [ $mrrm = 2 ]
then
clear
echo "\033[31;1m"
toilet "T-Sel"
echo "\033[31;1mJenis Spam:""\033[37;1mSMS"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mDanz"
clear
cd Tul/
php 2.php
fi

if [ $mrrm = 3 ] || [ $mrrm = 3 ]
then
clear
echo "\033[36;1m"
figlet "Grab"
echo "\033[31;1mJenis Spam:""\033[37;1mTelepon"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mRaja Adtiya Candra"
clear
cd Tul/
php 3.php
fi


if [ $mrrm = 4 ] || [ $mrrm = 4 ]
then
clear
toilet -f mono9 -F gay "Toked"
echo "\033[31;1mJenis Spam:""\033[37;1mTelepon"
echo "\033[31;1mBatas:""\033[37;1m1 Kali"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mSGB-Team"
clear
cd Tul/
php 4.php
fi

if [ $mrrm = 5 ] || [ $mrrm = 5 ]
then
clear
toilet -f slant -F gay "CodaShop"
echo "\033[31;1mJenis Spam:""\033[37;1mSMS"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mPHP"
echo "\033[31;1mAuthor:""\033[37;1mBullyHat"
echo
echo
echo "\033[33;1mCOPY LISENSI INI:" "\033[36;1mJDJ5JDEwJC9YMWRvNC5jcmNOSUw2dGdUaUt2d08ucWEvWURWSFNCTXI3U21wdkdsR1FMcVBSTW1oNUZH"
clear
cd Tul/
php 5.php
fi

if
[ $mrrm = 6 ] || [ $mrrm = 6 ]
then
clear
toilet -f standard -F gay "Surveyon "
echo "\033[31;1mJenis Spam:""\033[37;1mEmail"
echo "\033[31;1mBatas:""\033[37;1mUnlimited"
echo "\033[31;1mPemograman:""\033[37;1mphp"
echo "\033[31;1mAuthor:""\033[37;1mChandra Aditya"
cd Tul/
php 6.php
fi

if
[ $mrrm = 7 ] || [ $mrrm = 7 ]
then
clear
toilet -f slant --gay "SMSID"
echo "\033[31;1mJenis Spam:""\033[37;1mSMS"
echo "\033[31;1mBatas:""\033[37;1m5"
echo "\033[31;1mPemograman:""\033[37;1mBerjalan Langsung Pada DalvikVM"
echo "\033[31;1mAuthor:""\033[37;1mAmsitlab"
echo
echo
echo "\033[33;1mInformasi Lebih Lanjut Kunjungi:""\033[36;1mhttps://amsitlab.github.io/smsid-java/"
smsid boom -y
fi

if [ $mrrm = 8 ] || [ $mrrm = 8 ]
then
clear
echo "\033[34;1m"
figlet "JD.ID"
cd Tul
php 111.php
fi

if [ $mrrm = 9 ] || [ $mrrm = 9 ]
then
clear
echo "\033[33;1m"
toilet "H00Q"
cd Tul
php 555.php
fi

if [ $mrrm = 10 ] || [ $mrrm = 10 ]
then
clear
echo "\033[31;1m"
figlet "Matahari"
cd Tul
php 444.php
fi

if [ $mrrm = 11 ] || [ $mrrm = 11 ]
then
clear
toilet -f slant --gay "KFC"
echo "\033[31;1m"
cd Tul
php 666.php
fi

if [ $mrrm = 12 ] || [ $mrrm = 12 ]
then
clear
toilet -f mono12 -F gay "PHD"
echo "\033[30;1m"
cd Tul
php 777.php
fi

if [ $mrrm = 13 ] || [ $mrrm = 13 ]
then
clear
echo "\033[34;1m"
toilet "whiskas"
cd Tul
php 888.php
fi

if [ $mrrm = 14 ] || [ $mrrm = 14 ]
then
clear
echo "\33[33;1m"
figlet "ZiPAY"
cd Tul
php 999.php
fi

if
[ $mrrm = 0 ] || [ $mrrm = 0 ]
then
echo "\033[31;1m Keluar"
sleep 1
echo "\033[32;1m Sampai berjumpa lagi :)"
sleep 1
fi
